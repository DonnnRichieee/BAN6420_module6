** Fashion MNIST Classification with CNN in R **
	This project demonstrates building, training, and making predictions using a Convolutional Neural Network (CNN) on the Fashion MNIST dataset in R, leveraging the keras and reticulate packages.

* Requirements

- R studio or R
- Python 
- R Packages: keras, tensorflow

* Setup Instructions
Install R Packages: Install keras and tensorflow in R.

* Configure Python Environment:
- Install keras and tensorflow in the virtual environment.

* Running the Code
Load Libraries: Load keras and tensorflow libraries in R.

* Define and Initialize the Model: 
- Create a class FashionMNISTModel with methods to build, train, and predict using the CNN model.

- Load and Preprocess Data

- Normalize the images to the range [0, 1].

- Reshape the images to include the channel dimension.

- Create, Train, and Predict with the Model.

- Create an instance of the FashionMNISTModel.

- Train the model on the training data.

- Make predictions on two test images and display the results.
