# Load required libraries
library(keras)
library(tensorflow)

# Define the FashionMNISTModel class
FashionMNISTModel <- setRefClass(
  "FashionMNISTModel",
  fields = list(
    model = "ANY"
  ),
  methods = list(
    initialize = function() {
      # Initialize the model by defining its architecture
      model <<- build_model()
    },
    
    build_model = function() {
      # Defines the CNN architecture with six layers.
      model <- keras_model_sequential() %>%
        layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
        layer_max_pooling_2d(pool_size = c(2, 2)) %>%
        layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
        layer_max_pooling_2d(pool_size = c(2, 2)) %>%
        layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
        layer_flatten() %>%
        layer_dense(units = 64, activation = 'relu') %>%
        layer_dense(units = 10, activation = 'softmax')
      
      # Compile the model with the Adam optimizer and sparse categorical crossentropy loss function
      model %>% compile(
        optimizer = 'adam',
        loss = 'sparse_categorical_crossentropy',
        metrics = 'accuracy'
      )
      
      return(model)
    },
    
    train = function(train_images, train_labels, epochs = 10, validation_data = NULL) {
      # Trains the model on the provided training data.
      # Args:
      #   train_images (array): The training images.
      #   train_labels (array): The training labels.
      #   epochs (int): The number of epochs to train. Default is 10.
      #   validation_data (list): A list of validation images and labels. Optional.
      model %>% fit(
        train_images, train_labels,
        epochs = epochs,
        validation_data = validation_data
      )
    },
    
    predict = function(images) {
      # Makes predictions on the provided images.
      # Args:
      #   images (array): The images to make predictions on.
      # Returns:
      #   predicted_labels (array): The predicted labels for the images.
      predictions <- model %>% predict(images)
      predicted_labels <- apply(predictions, 1, which.max) - 1 # Adjust for 0-based index
      return(predicted_labels)
    }
  )
)

# Load and preprocess the data
fashion_mnist <- dataset_fashion_mnist()
c(train_images, train_labels) %<-% fashion_mnist$train
c(test_images, test_labels) %<-% fashion_mnist$test

# Normalize the images to the range [0, 1]
train_images <- train_images / 255
test_images <- test_images / 255

# Reshape the images to include the channel dimension
train_images <- array_reshape(train_images, c(dim(train_images)[1], 28, 28, 1))
test_images <- array_reshape(test_images, c(dim(test_images)[1], 28, 28, 1))

# Create an instance of the model
model <- FashionMNISTModel$new()

# Train the model
model$train(train_images, train_labels, epochs = 10, validation_data = list(test_images, test_labels))

# Make predictions on two test images
predictions <- model$predict(test_images[1:2, , , ])
print(paste("Predicted labels for the first two images:", toString(predictions)))



